class storage:
    def __init__(self):
        self.devices = {}
